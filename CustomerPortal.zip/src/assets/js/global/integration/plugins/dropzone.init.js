Dropzone.autoDiscover = false;
