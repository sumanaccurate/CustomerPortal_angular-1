export class User {
    UserCodetxt: string;
    UserNametxt: string;
    UserTypetxt: string;
    Divisionvtxt: string;
    Mobilevtxt: string;
    Emailvtxt: string;
}
